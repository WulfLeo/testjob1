<?php
add_action( 'wp_enqueue_scripts', 'enqueue_parent_styles' );
    
function enqueue_parent_styles() {
   wp_enqueue_style( 'parent-style', get_template_directory_uri().'/style.css' );
}

function wc_europrice_product_field() {
woocommerce_wp_text_input( array( 'id' => '_euro_price', 'class' => 'wc_input_price short', 'label' => __( 'EUR', 'woocommerce' ) ) );
}
add_action( 'woocommerce_product_options_pricing', 'wc_europrice_product_field' );

function wc_myprice_save_product( $product_id ) {

if ( ( $_POST['_euro_price'] ) ) {
if ( is_numeric( $_POST['_euro_price'] ) )
update_post_meta( $product_id, '_euro_price', $_POST['_euro_price'] );
} else delete_post_meta( $product_id, '_euro_price' );
}
add_action( 'save_post', 'wc_myprice_save_product' );


function wc_myprice_show() {
global $product, $post;
// Ничего не предпринимаем для вариативных товаров
//if ( $product->product_type <> 'variable' ) {
$EUR = get_post_meta( $product->id, '_euro_price', true );

  // Получаем текущие курсы валют в rss-формате с сайта www.cbr.ru 
  $content = $text; 
  // Разбираем содержимое, при помощи регулярных выражений 
  $pattern = "#<Valute ID=\"([^\"]+)[^>]+>[^>]+>([^<]+)[^>]+>[^>]+>[^>]+>[^>]+>[^>]+>[^>]+>([^<]+)[^>]+>[^>]+>([^<]+)#i"; 
  preg_match_all($pattern, $content, $out, PREG_SET_ORDER); 
  $euro = ""; 
  foreach($out as $cur) 
  { 
    if($cur[2] == 978) $euro   = str_replace(",",".",$cur[4]); 
  }

$regular_price = get_post_meta($post->ID, '_price', true); //получаем текущую цену товара

//if ($regular_price != $ $custom_price) { // проверяем совпадает ли текущая цена с нашей новой, если нет, то перезаписываем её
//update_post_meta( $post->ID, '_regular_price', $custom_price );
//update_post_meta( $post->ID, '_price', $custom_price );	

//можно вывести нашу custom_price для проверки
  echo '<div class="woocommerce_msrp">';
  _e( 'EUR : ', 'woocommerce' );
  echo '<span class="woocommerce-rrp-price EUR">' . $EUR . '</span>';
  echo '</div>';
}

//}
//}
add_action( 'woocommerce_single_product_summary', 'wc_myprice_show', 5 ); 
// Дополнительно: Для вывода на страницах архивов (в товарных категориях, например)
add_action( 'woocommerce_after_shop_loop_item_title', 'wc_myprice_show' );
