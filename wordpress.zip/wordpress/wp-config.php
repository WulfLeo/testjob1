<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'wordpress_work');

/** Имя пользователя MySQL */
define('DB_USER', 'root');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', '');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '/{KuwL:,&rQA{g>=O0q`DH1#v^c/<Cy6?D1s4N;^[n3#cx%i7(!N6l-XXl7yPYP_');
define('SECURE_AUTH_KEY',  'C*U:T=fYD*|ye4#4fJE,M|~cl>?f=puW?d=DYe,{c0$Kvb&Z`^$1QVkLpk5Vk%AX');
define('LOGGED_IN_KEY',    '!P^>O8g|_-p1V(mR|pzufHYwAx]vE{i2oY_J:&b;f.2O/Fq[04tGxI4BGZBTwyqx');
define('NONCE_KEY',        'R<EIe}3-|86B^|j!92o?$&gV#>(nwM/s=<>aJkp!7 >.M(Mg3Q_b)S6>*o3maAC.');
define('AUTH_SALT',        'u-3@_<hgm1]P$NecrRoT,}CFi&A4S1Two`0d}3.eK+a0BhS(dkq#&OZoR&pUT]dK');
define('SECURE_AUTH_SALT', 'aNVlW&L_B5AJB$y.R;B5&Hk2(d-F*fWIt<f_%~$JP>,TI~0XbO)SEdb~C3]t9(e3');
define('LOGGED_IN_SALT',   '?NUU^jK6 Kv]|`S%/#UhYKCWO&,OCL|=[azR),L(b]xT3Pk%q-.-2,WTW*BLGBUj');
define('NONCE_SALT',       '_|[.7s4_!&o+,g[P7-C|q! b_(Q~pTBX]*YPK7z#5P20%mc.,*@y-g3G>Q@_HB<h');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
